/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo_1301194258_mod3_jurnal;

public class Album {
    
    public String title;
    public int year;
    public int track;
    public Song songs[];

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if(title == null){
            System.out.println("Title Tidak Boleh Kosong. ");
        }
        this.title = title;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setTotalSongs(int track) {
        songs = new Song[track];
    }
    
    public void addSong(Song s){
        songs[track]=s;
        track++;
    }
    
    public void displayInfo(){
        System.out.println("Album Info");
        System.out.println("Title: " + getTitle());
        System.out.println("Year: " + getYear());
        System.out.println("Song List");
        for(int i = 0; i < songs.length;i++){
            System.out.println((i+1) + " Title: "+ songs[i].getTitle());
            System.out.println(" Artist: " + songs[i].getArtist());
            System.out.println(" Duration: " + songs[i].getDuration());
            System.out.print(" Category: ");
            songs[i].play();
            
        }
    }
    
    
}
