/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo_1301194258_mod3_jurnal;

public class Song {

    public String title;
    public String artist;
    public int duration;
    
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title==null){
            System.out.println("Title Tidak Boleh Kosong. ");
        }else{
            this.title = title;
        }
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        if(artist==null){
            System.out.println("Artist Tidak Boleh Kosong. ");
        }else{
            this.artist = artist;
        }
    }

    public String getDuration() {
//        int minutes = (duration % 3600)/60;
        int minutes = duration / 60;
        int seconds = duration %60;
        return String.format("%d:%d",minutes,seconds);
    }

    public void setDuration(int duration) {
        if(duration >= 0 && duration <=300){
            this.duration = duration;
        }else{
            System.out.println("Durasi Tidak Boleh Kurang Dari 0 dan Tidak Bileh Lebih Dari 300");
        }
    }
    
    public void play(){
        if(duration > 0 && duration < 120){
            System.out.println("Short");
        }else if (duration >= 120 && duration <=240){
            System.out.println("Intermediate");
        }else if (duration > 240){
            System.out.println("Long");
        }
    }
    
    
}
