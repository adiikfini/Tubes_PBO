/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo_1301194258_mod3_jurnal;

/**
 *
 * @author WIBU
 */
public class DriverAlbum {
    
    public static void main(String[] args) {
        Song song1 = new Song();
        Song song2 = new Song();
        
        song1.setTitle("Melukis Senja");
        song1.setArtist("Budi Doremi");
        song1.setDuration(240);
        song2.setTitle("Photograph");
        song2.setArtist("Ed Sheeran");
        song2.setDuration(274);
        
        Album albumm = new Album();
        albumm.setTitle("Pernah Hits");
        albumm.setYear(2021);
        albumm.setTotalSongs(2);
        
        albumm.addSong(song1);
        albumm.addSong(song2);
        
        albumm.displayInfo();
    }
}
